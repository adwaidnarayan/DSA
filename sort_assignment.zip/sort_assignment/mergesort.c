/*
 * mergesort.c
 * Bottom-up (iterative) MergeSort implementation.
 * Prints the array contents after every individual merge operation,
 * and after each full pass (pass = one doubling of the merged-run width),
 * along with a running count of comparisons and merge operations.
 *
 * Compile: gcc -O0 -o mergesort mergesort.c
 * Run:     ./mergesort input.txt
 */
#include <stdio.h>
#include <stdlib.h>

long comparisons = 0;
long merge_ops = 0; /* number of merge() calls */

void print_array(int arr[], int n, const char *label) {
    printf("%-28s: [", label);
    for (int i = 0; i < n; i++) {
        printf("%d", arr[i]);
        if (i != n - 1) printf(", ");
    }
    printf("]\n");
}

/* Merge arr[l..m] and arr[m+1..r] */
void merge(int arr[], int l, int m, int r, int pass_num) {
    int n1 = m - l + 1;
    int n2 = r - m;
    int L[100], R[100];
    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        comparisons++;
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    merge_ops++;
    printf("  Pass %d | merge indices [%d..%d] + [%d..%d] -> ", pass_num, l, m, m + 1, r);
    printf("[");
    for (int t = l; t <= r; t++) {
        printf("%d", arr[t]);
        if (t != r) printf(", ");
    }
    printf("]\n");
}

void merge_sort_bottom_up(int arr[], int n) {
    printf("\n=== MergeSort Trace ===\n");
    print_array(arr, n, "Initial array");

    int pass_num = 0;
    for (int width = 1; width < n; width *= 2) {
        pass_num++;
        printf("\n-- Pass %d (subarray width = %d) --\n", pass_num, width);
        for (int l = 0; l < n - 1; l += 2 * width) {
            int m = l + width - 1;
            if (m >= n - 1) continue; /* only one run left, nothing to merge */
            int r = (l + 2 * width - 1 < n - 1) ? (l + 2 * width - 1) : (n - 1);
            merge(arr, l, m, r, pass_num);
        }
        char label[40];
        snprintf(label, sizeof(label), "After pass %d (width %d)", pass_num, width);
        print_array(arr, n, label);
    }
    printf("\n=== MergeSort finished ===\n");
    print_array(arr, n, "Final sorted array");
    printf("Total comparisons : %ld\n", comparisons);
    printf("Total merge calls : %ld\n", merge_ops);
    printf("Total passes      : %d\n", pass_num);
}

int main(int argc, char *argv[]) {
    int arr[100];
    int n = 0;

    FILE *f = NULL;
    if (argc > 1) f = fopen(argv[1], "r");
    if (f) {
        while (fscanf(f, "%d", &arr[n]) == 1) n++;
        fclose(f);
    } else {
        printf("Enter number of elements: ");
        scanf("%d", &n);
        printf("Enter %d elements: ", n);
        for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    }

    merge_sort_bottom_up(arr, n);
    return 0;
}
