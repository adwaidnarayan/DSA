# MergeSort vs QuickSort — Sorting Fixed-Length Social Media IDs

## Problem
A social media application needs to sort the following fixed-length 3-digit IDs:

```
324, 125, 456, 218, 102, 389, 275, 147
```

Tasks: implement MergeSort and QuickSort in C, trace their execution, analyse
their performance, and recommend the more suitable algorithm for large
fixed-length keys.

## Repository contents
| File | Purpose |
|---|---|
| `mergesort.c` | Bottom-up (iterative) MergeSort, traces every merge |
| `quicksort.c` | QuickSort with Lomuto partitioning, traces every partition |
| `input.txt` | The 8 input IDs |
| `output_mergesort.txt` | Captured program output for MergeSort |
| `output_quicksort.txt` | Captured program output for QuickSort |
| `README.md` | This report: trace tables, complexity analysis, comparison, conclusion |

## How to build and run
```bash
gcc -O0 -Wall -o mergesort mergesort.c
gcc -O0 -Wall -o quicksort quicksort.c
./mergesort input.txt   > output_mergesort.txt
./quicksort input.txt   > output_quicksort.txt
```

---

## a) MergeSort — execution and trace table

MergeSort was implemented **bottom-up**: it repeatedly merges adjacent
sub-arrays of a given width (1, then 2, then 4), doubling the width each
pass, until the whole array is one sorted run. `log2(8) = 3` passes are
needed for 8 elements.

**Initial array:** `[324, 125, 456, 218, 102, 389, 275, 147]`

| Pass | Width | Merge operation | Array after this merge |
|---|---|---|---|
| 1 | 1 | merge [324] + [125] | [125, 324, 456, 218, 102, 389, 275, 147] |
| 1 | 1 | merge [456] + [218] | [125, 324, 218, 456, 102, 389, 275, 147] |
| 1 | 1 | merge [102] + [389] | [125, 324, 218, 456, 102, 389, 275, 147] |
| 1 | 1 | merge [275] + [147] | [125, 324, 218, 456, 102, 389, 147, 275] |
| **After pass 1** | | | **[125, 324, 218, 456, 102, 389, 147, 275]** |
| 2 | 2 | merge [125,324] + [218,456] | [125, 218, 324, 456, 102, 389, 147, 275] |
| 2 | 2 | merge [102,389] + [147,275] | [125, 218, 324, 456, 102, 147, 275, 389] |
| **After pass 2** | | | **[125, 218, 324, 456, 102, 147, 275, 389]** |
| 3 | 4 | merge [125,218,324,456] + [102,147,275,389] | [102, 125, 147, 218, 275, 324, 389, 456] |
| **After pass 3 (final)** | | | **[102, 125, 147, 218, 275, 324, 389, 456]** |

**Totals:** 3 passes, 7 merge operations, **17 comparisons** (from actual run output).

---

## b) QuickSort — execution and trace table

QuickSort was implemented with the **Lomuto partition scheme**, always
choosing the **last element** of the current sub-range as the pivot.

**Initial array:** `[324, 125, 456, 218, 102, 389, 275, 147]`

| Partition # | Range (indices) | Pivot | Result of partition | Pivot's final index |
|---|---|---|---|---|
| 1 | [0..7] | 147 | [125, 102, 147, 218, 324, 389, 275, 456] | 2 |
| 2 | [0..1] | 102 | [102, 125] | 0 |
| 3 | [3..7] | 456 | [218, 324, 389, 275, 456] | 7 |
| 4 | [3..6] | 275 | [218, 275, 389, 324] | 4 |
| 5 | [5..6] | 324 | [324, 389] | 5 |

**Final sorted array:** `[102, 125, 147, 218, 275, 324, 389, 456]`

**Totals:** 5 partition calls, **16 comparisons**, 12 swaps (from actual run output).

---

## c) Complexity analysis and comparison

| Criterion | MergeSort | QuickSort |
|---|---|---|
| Passes / partitions (this run) | 3 passes | 5 partition calls |
| Comparisons (this run) | 17 | 16 |
| Extra swaps/moves | 0 explicit swaps (rebuilt via temp arrays) | 12 |
| Best-case time | O(n log n) | O(n log n) |
| Average-case time | O(n log n) | O(n log n) |
| Worst-case time | **O(n log n)** (guaranteed, independent of input order) | **O(n²)** (occurs on already sorted/reverse-sorted data with last-element pivot) |
| Space complexity | **O(n)** auxiliary (temporary arrays for merging) | **O(log n)** auxiliary on average (recursion stack); O(n) stack in worst case |
| Stability | Stable | Not stable (Lomuto swaps can reorder equal keys) |
| In-place? | No | Yes |

On this specific 8-element input the two algorithms performed almost
identically (17 vs 16 comparisons), because the data is small and not
adversarial. The real difference shows up at scale and on adversarial
inputs:

- **MergeSort's** performance is *guaranteed* — every input, regardless of
  original order, takes O(n log n) time. The cost is O(n) extra memory for
  the merge step.
- **QuickSort's** average performance is excellent and it needs almost no
  extra memory, but with a fixed pivot choice (like "last element" used
  here) it degrades to O(n²) on already-sorted or reverse-sorted input —
  a realistic risk for IDs that a system might insert in sorted or
  near-sorted batches. This risk can be reduced (not eliminated) with a
  randomized or median-of-three pivot.

## Final conclusion

For **large collections of fixed-length keys** such as these social-media
IDs, **MergeSort is the more suitable choice** when predictable, worst-case
performance matters (e.g., IDs may arrive in sorted or partially sorted
batches, which is QuickSort's worst case). MergeSort's O(n log n) guarantee
and stability outweigh its O(n) memory overhead on modern systems.

If memory is tightly constrained and the input order is known to be
sufficiently random, **QuickSort (with a randomized pivot)** is a strong
alternative because it sorts in place and is typically faster in practice
due to lower constant factors and better cache locality.

*(Note: because these are fixed-length, fixed-radix integer keys, a
non-comparison-based method such as Radix Sort would in principle beat
both — O(d·(n+k)) — but that is outside the two algorithms this assignment
compares.)*
