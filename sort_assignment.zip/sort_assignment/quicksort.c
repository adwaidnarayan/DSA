/*
 * quicksort.c
 * QuickSort implementation using Lomuto partition scheme (last element as pivot).
 * Prints the array state and pivot position after every partition operation.
 *
 * Compile: gcc -O0 -o quicksort quicksort.c
 * Run:     ./quicksort input.txt
 */
#include <stdio.h>
#include <stdlib.h>

long comparisons = 0;
long partition_calls = 0;
long swaps = 0;

void print_array(int arr[], int n, const char *label) {
    printf("%-28s: [", label);
    for (int i = 0; i < n; i++) {
        printf("%d", arr[i]);
        if (i != n - 1) printf(", ");
    }
    printf("]\n");
}

void swap(int *a, int *b) {
    int t = *a; *a = *b; *b = t;
    swaps++;
}

int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        comparisons++;
        if (arr[j] < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    partition_calls++;

    printf("  Partition #%ld | range [%d..%d], pivot = %d -> pivot placed at index %d | ",
           partition_calls, low, high, pivot, i + 1);
    printf("[");
    for (int t = low; t <= high; t++) {
        printf("%d", arr[t]);
        if (t != high) printf(", ");
    }
    printf("]\n");

    return i + 1;
}

void quick_sort(int arr[], int low, int high, int n) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quick_sort(arr, low, pi - 1, n);
        quick_sort(arr, pi + 1, high, n);
    }
}

int main(int argc, char *argv[]) {
    int arr[100];
    int n = 0;

    FILE *f = NULL;
    if (argc > 1) f = fopen(argv[1], "r");
    if (f) {
        while (fscanf(f, "%d", &arr[n]) == 1) n++;
        fclose(f);
    } else {
        printf("Enter number of elements: ");
        scanf("%d", &n);
        printf("Enter %d elements: ", n);
        for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    }

    printf("\n=== QuickSort Trace (Lomuto partition, pivot = last element) ===\n");
    print_array(arr, n, "Initial array");
    printf("\n");

    quick_sort(arr, 0, n - 1, n);

    printf("\n=== QuickSort finished ===\n");
    print_array(arr, n, "Final sorted array");
    printf("Total comparisons     : %ld\n", comparisons);
    printf("Total partition calls : %ld\n", partition_calls);
    printf("Total swaps           : %ld\n", swaps);
    return 0;
}
